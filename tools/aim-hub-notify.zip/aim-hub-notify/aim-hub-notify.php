<?php
/**
 * Plugin Name: AIM Hub Notify Relay
 * Description: Receives secret-authenticated POSTs from the EHS Hub backend (Supabase) and emails Chad via the site's WP Mail SMTP pipe. Fixed recipient, rate-limited. No settings UI.
 * Version: 1.0.0
 * Author: AIM Environmental Health & Safety
 */
if (!defined('ABSPATH')) exit;

function aim_hub_notify_secret() {
    $s = get_option('aim_notify_secret');
    if (!$s) {
        $s = wp_generate_password(48, false, false);
        add_option('aim_notify_secret', $s, '', 'no');
    }
    return $s;
}
register_activation_hook(__FILE__, 'aim_hub_notify_secret');

add_action('rest_api_init', function () {
    register_rest_route('aim/v1', '/notify', [
        'methods'  => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function ($req) {
            $given = (string) $req->get_header('x-aim-secret');
            if (!$given || !hash_equals(aim_hub_notify_secret(), $given)) {
                return new WP_Error('forbidden', 'forbidden', ['status' => 403]);
            }
            $n = (int) get_transient('aim_notify_n');
            if ($n >= 40) return new WP_Error('rate_limited', 'rate limited', ['status' => 429]);
            set_transient('aim_notify_n', $n + 1, DAY_IN_SECONDS);
            $p = $req->get_json_params();
            $subject = mb_substr(sanitize_text_field(isset($p['subject']) ? $p['subject'] : 'EHS Hub notification'), 0, 140);
            $body = mb_substr(sanitize_textarea_field(isset($p['body']) ? $p['body'] : ''), 0, 2000);
            $ok = wp_mail('chad@aim-env.com', $subject, $body);
            return ['ok' => (bool) $ok];
        },
    ]);
    register_rest_route('aim/v1', '/notify-secret', [
        'methods'  => 'GET',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback' => function () { return ['secret' => aim_hub_notify_secret()]; },
    ]);
});
